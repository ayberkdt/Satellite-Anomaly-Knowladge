# SAK Early Warning Report

- **Event ID:** DENSE_AUTOENCODER-SAK-0002
- **Alarm time:** 2026-01-12T13:36:00+00:00
- **Event interval:** 2026-01-12T11:31:00+00:00 — 2026-01-12T13:48:00+00:00
- **Anomaly score:** 0.6757
- **Threshold:** 0.0574
- **Risk level:** HIGH
- **Operational context:** operational_mode=nominal, eclipse=False, orbit_phase=0.5
- **Critical time window:** 2026-01-12T13:27:00+00:00 — 2026-01-12T13:37:00+00:00
- **Possible subsystem:** EPS, THERMAL
- **Attribution concentration:** 85.0%
- **Model confidence / uncertainty:** Henüz kalibre edilmedi

## Top Contributing Telemetry Channels

- battery_temperature: 0.686 (EPS) [high]
- panel_temperature: 0.108 (THERMAL) [low]
- payload_temperature: 0.057 (THERMAL) [low]
- bus_voltage: 0.050 (EPS) [high]
- receiver_rssi: 0.026 (COMM) [low]

## Engineering Interpretation

EPS grubunda reconstruction error yükseldi. Başlıca kanallar: battery_temperature, panel_temperature, payload_temperature. Bu çıktı kök neden kanıtı değil, mühendislik inceleme önceliğidir.

## Suggested Next Inspection

1. İlgili alt sistemin limit ve durum telemetrilerini doğrula.
2. Aynı operasyon modu ve yörünge fazındaki nominal örneklerle karşılaştır.
3. Komut, olay ve bakım kayıtlarını kritik pencereyle zaman hizalı incele.
