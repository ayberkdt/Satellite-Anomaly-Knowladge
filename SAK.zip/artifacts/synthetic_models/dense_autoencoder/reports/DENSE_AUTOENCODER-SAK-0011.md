# SAK Early Warning Report

- **Event ID:** DENSE_AUTOENCODER-SAK-0011
- **Alarm time:** 2026-01-14T08:08:00+00:00
- **Event interval:** 2026-01-14T08:03:00+00:00 — 2026-01-14T08:41:00+00:00
- **Anomaly score:** 0.1262
- **Threshold:** 0.0574
- **Risk level:** MEDIUM
- **Operational context:** operational_mode=nominal, eclipse=False, orbit_phase=0.08333333333333333
- **Critical time window:** 2026-01-14T08:03:00+00:00 — 2026-01-14T08:10:00+00:00
- **Possible subsystem:** THERMAL, COMM
- **Attribution concentration:** 67.2%
- **Model confidence / uncertainty:** Henüz kalibre edilmedi

## Top Contributing Telemetry Channels

- panel_temperature: 0.271 (THERMAL) [high]
- payload_temperature: 0.233 (THERMAL) [high]
- bus_voltage: 0.168 (EPS) [high]
- receiver_rssi: 0.127 (COMM) [high]
- transmitter_power: 0.109 (COMM) [low]

## Engineering Interpretation

THERMAL grubunda reconstruction error yükseldi. Başlıca kanallar: panel_temperature, payload_temperature, bus_voltage. Bu çıktı kök neden kanıtı değil, mühendislik inceleme önceliğidir.

## Suggested Next Inspection

1. İlgili alt sistemin limit ve durum telemetrilerini doğrula.
2. Aynı operasyon modu ve yörünge fazındaki nominal örneklerle karşılaştır.
3. Komut, olay ve bakım kayıtlarını kritik pencereyle zaman hizalı incele.
