# SAK Early Warning Report

- **Event ID:** DENSE_AUTOENCODER-SAK-0007
- **Alarm time:** 2026-01-13T15:28:00+00:00
- **Event interval:** 2026-01-13T13:20:00+00:00 — 2026-01-13T16:11:00+00:00
- **Anomaly score:** 0.8522
- **Threshold:** 0.0574
- **Risk level:** HIGH
- **Operational context:** operational_mode=nominal, eclipse=True, orbit_phase=0.6666666666666666
- **Critical time window:** 2026-01-13T15:23:00+00:00 — 2026-01-13T15:33:00+00:00
- **Possible subsystem:** EPS, THERMAL
- **Attribution concentration:** 88.3%
- **Model confidence / uncertainty:** Henüz kalibre edilmedi

## Top Contributing Telemetry Channels

- bus_voltage: 0.808 (EPS) [high]
- battery_voltage: 0.046 (EPS) [low]
- payload_temperature: 0.029 (THERMAL) [low]
- reaction_wheel_speed: 0.023 (AOCS) [low]
- receiver_rssi: 0.022 (COMM) [low]

## Engineering Interpretation

EPS grubunda reconstruction error yükseldi. Başlıca kanallar: bus_voltage, battery_voltage, payload_temperature. Bu çıktı kök neden kanıtı değil, mühendislik inceleme önceliğidir.

## Suggested Next Inspection

1. İlgili alt sistemin limit ve durum telemetrilerini doğrula.
2. Aynı operasyon modu ve yörünge fazındaki nominal örneklerle karşılaştır.
3. Komut, olay ve bakım kayıtlarını kritik pencereyle zaman hizalı incele.
