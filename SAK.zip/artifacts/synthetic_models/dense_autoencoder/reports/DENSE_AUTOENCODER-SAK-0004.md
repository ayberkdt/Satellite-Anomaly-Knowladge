# SAK Early Warning Report

- **Event ID:** DENSE_AUTOENCODER-SAK-0004
- **Alarm time:** 2026-01-12T23:57:00+00:00
- **Event interval:** 2026-01-12T23:06:00+00:00 — 2026-01-13T00:07:00+00:00
- **Anomaly score:** 0.3113
- **Threshold:** 0.0574
- **Risk level:** HIGH
- **Operational context:** operational_mode=nominal, eclipse=True, orbit_phase=0.96875
- **Critical time window:** 2026-01-12T23:42:00+00:00 — 2026-01-12T23:52:00+00:00
- **Possible subsystem:** EPS
- **Attribution concentration:** 74.9%
- **Model confidence / uncertainty:** Henüz kalibre edilmedi

## Top Contributing Telemetry Channels

- battery_voltage: 0.582 (EPS) [low]
- bus_voltage: 0.084 (EPS) [high]
- battery_current: 0.083 (EPS) [high]
- solar_array_voltage: 0.071 (EPS) [low]
- solar_array_current: 0.055 (EPS) [low]

## Engineering Interpretation

EPS grubunda reconstruction error yükseldi. Başlıca kanallar: battery_voltage, bus_voltage, battery_current. Bu çıktı kök neden kanıtı değil, mühendislik inceleme önceliğidir.

## Suggested Next Inspection

1. İlgili alt sistemin limit ve durum telemetrilerini doğrula.
2. Aynı operasyon modu ve yörünge fazındaki nominal örneklerle karşılaştır.
3. Komut, olay ve bakım kayıtlarını kritik pencereyle zaman hizalı incele.
