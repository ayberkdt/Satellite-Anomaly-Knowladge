# SAK Early Warning Report

- **Event ID:** DENSE_AUTOENCODER-SAK-0010
- **Alarm time:** 2026-01-14T04:06:00+00:00
- **Event interval:** 2026-01-14T04:05:00+00:00 — 2026-01-14T04:10:00+00:00
- **Anomaly score:** 0.0727
- **Threshold:** 0.0574
- **Risk level:** LOW
- **Operational context:** operational_mode=payload, eclipse=False, orbit_phase=0.5625
- **Critical time window:** 2026-01-14T04:05:00+00:00 — 2026-01-14T04:10:00+00:00
- **Possible subsystem:** COMM, THERMAL
- **Attribution concentration:** 63.1%
- **Model confidence / uncertainty:** Henüz kalibre edilmedi

## Top Contributing Telemetry Channels

- transmitter_power: 0.268 (COMM) [high]
- payload_temperature: 0.246 (THERMAL) [high]
- battery_temperature: 0.117 (EPS) [high]
- bus_voltage: 0.115 (EPS) [low]
- receiver_rssi: 0.110 (COMM) [low]

## Engineering Interpretation

COMM grubunda reconstruction error yükseldi. Başlıca kanallar: transmitter_power, payload_temperature, battery_temperature. Bu çıktı kök neden kanıtı değil, mühendislik inceleme önceliğidir.

## Suggested Next Inspection

1. İlgili alt sistemin limit ve durum telemetrilerini doğrula.
2. Aynı operasyon modu ve yörünge fazındaki nominal örneklerle karşılaştır.
3. Komut, olay ve bakım kayıtlarını kritik pencereyle zaman hizalı incele.
