# SAK Early Warning Report

- **Event ID:** DENSE_AUTOENCODER-SAK-0001
- **Alarm time:** 2026-01-12T06:57:00+00:00
- **Event interval:** 2026-01-12T06:50:00+00:00 — 2026-01-12T07:27:00+00:00
- **Anomaly score:** 46.2206
- **Threshold:** 0.0574
- **Risk level:** HIGH
- **Operational context:** operational_mode=payload, eclipse=False, orbit_phase=0.34375
- **Critical time window:** 2026-01-12T06:52:00+00:00 — 2026-01-12T07:02:00+00:00
- **Possible subsystem:** EPS, THERMAL
- **Attribution concentration:** 93.0%
- **Model confidence / uncertainty:** Henüz kalibre edilmedi

## Top Contributing Telemetry Channels

- bus_voltage: 0.882 (EPS) [high]
- payload_temperature: 0.024 (THERMAL) [high]
- battery_temperature: 0.024 (EPS) [high]
- panel_temperature: 0.024 (THERMAL) [high]
- reaction_wheel_speed: 0.016 (AOCS) [high]

## Engineering Interpretation

EPS grubunda reconstruction error yükseldi. Başlıca kanallar: bus_voltage, payload_temperature, battery_temperature. Bu çıktı kök neden kanıtı değil, mühendislik inceleme önceliğidir.

## Suggested Next Inspection

1. İlgili alt sistemin limit ve durum telemetrilerini doğrula.
2. Aynı operasyon modu ve yörünge fazındaki nominal örneklerle karşılaştır.
3. Komut, olay ve bakım kayıtlarını kritik pencereyle zaman hizalı incele.
