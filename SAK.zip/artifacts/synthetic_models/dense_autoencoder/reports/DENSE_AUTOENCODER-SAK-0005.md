# SAK Early Warning Report

- **Event ID:** DENSE_AUTOENCODER-SAK-0005
- **Alarm time:** 2026-01-13T04:28:00+00:00
- **Event interval:** 2026-01-13T04:04:00+00:00 — 2026-01-13T04:49:00+00:00
- **Anomaly score:** 0.1054
- **Threshold:** 0.0574
- **Risk level:** MEDIUM
- **Operational context:** operational_mode=payload, eclipse=True, orbit_phase=0.7916666666666666
- **Critical time window:** 2026-01-13T04:10:00+00:00 — 2026-01-13T04:20:00+00:00
- **Possible subsystem:** EPS, THERMAL
- **Attribution concentration:** 68.8%
- **Model confidence / uncertainty:** Henüz kalibre edilmedi

## Top Contributing Telemetry Channels

- solar_array_current: 0.499 (EPS) [high]
- payload_temperature: 0.123 (THERMAL) [high]
- bus_voltage: 0.067 (EPS) [low]
- battery_voltage: 0.060 (EPS) [low]
- transmitter_power: 0.054 (COMM) [high]

## Engineering Interpretation

EPS grubunda reconstruction error yükseldi. Başlıca kanallar: solar_array_current, payload_temperature, bus_voltage. Bu çıktı kök neden kanıtı değil, mühendislik inceleme önceliğidir.

## Suggested Next Inspection

1. İlgili alt sistemin limit ve durum telemetrilerini doğrula.
2. Aynı operasyon modu ve yörünge fazındaki nominal örneklerle karşılaştır.
3. Komut, olay ve bakım kayıtlarını kritik pencereyle zaman hizalı incele.
