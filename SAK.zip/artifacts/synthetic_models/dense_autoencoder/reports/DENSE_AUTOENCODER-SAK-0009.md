# SAK Early Warning Report

- **Event ID:** DENSE_AUTOENCODER-SAK-0009
- **Alarm time:** 2026-01-14T01:18:00+00:00
- **Event interval:** 2026-01-14T01:00:00+00:00 — 2026-01-14T02:52:00+00:00
- **Anomaly score:** 1.7079
- **Threshold:** 0.0574
- **Risk level:** HIGH
- **Operational context:** operational_mode=nominal, eclipse=True, orbit_phase=0.8125
- **Critical time window:** 2026-01-14T01:00:00+00:00 — 2026-01-14T01:10:00+00:00
- **Possible subsystem:** EPS
- **Attribution concentration:** 81.2%
- **Model confidence / uncertainty:** Henüz kalibre edilmedi

## Top Contributing Telemetry Channels

- battery_voltage: 0.659 (EPS) [low]
- bus_voltage: 0.077 (EPS) [high]
- solar_array_voltage: 0.076 (EPS) [low]
- solar_array_current: 0.067 (EPS) [low]
- battery_current: 0.051 (EPS) [high]

## Engineering Interpretation

EPS grubunda reconstruction error yükseldi. Başlıca kanallar: battery_voltage, bus_voltage, solar_array_voltage. Bu çıktı kök neden kanıtı değil, mühendislik inceleme önceliğidir.

## Suggested Next Inspection

1. İlgili alt sistemin limit ve durum telemetrilerini doğrula.
2. Aynı operasyon modu ve yörünge fazındaki nominal örneklerle karşılaştır.
3. Komut, olay ve bakım kayıtlarını kritik pencereyle zaman hizalı incele.
