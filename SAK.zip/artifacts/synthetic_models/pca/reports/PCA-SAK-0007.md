# SAK Early Warning Report

- **Event ID:** PCA-SAK-0007
- **Alarm time:** 2026-01-13T14:23:00+00:00
- **Event interval:** 2026-01-13T13:20:00+00:00 — 2026-01-13T16:11:00+00:00
- **Anomaly score:** 0.9129
- **Threshold:** 0.0627
- **Risk level:** HIGH
- **Operational context:** operational_mode=nominal, eclipse=True, orbit_phase=0.9895833333333334
- **Critical time window:** 2026-01-13T14:18:00+00:00 — 2026-01-13T14:28:00+00:00
- **Possible subsystem:** EPS, AOCS
- **Attribution concentration:** 84.9%
- **Model confidence / uncertainty:** Henüz kalibre edilmedi

## Top Contributing Telemetry Channels

- bus_voltage: 0.761 (EPS) [high]
- battery_voltage: 0.048 (EPS) [low]
- reaction_wheel_speed: 0.039 (AOCS) [low]
- transmitter_power: 0.038 (COMM) [high]
- payload_temperature: 0.029 (THERMAL) [low]

## Engineering Interpretation

EPS grubunda reconstruction error yükseldi. Başlıca kanallar: bus_voltage, battery_voltage, reaction_wheel_speed. Bu çıktı kök neden kanıtı değil, mühendislik inceleme önceliğidir.

## Suggested Next Inspection

1. İlgili alt sistemin limit ve durum telemetrilerini doğrula.
2. Aynı operasyon modu ve yörünge fazındaki nominal örneklerle karşılaştır.
3. Komut, olay ve bakım kayıtlarını kritik pencereyle zaman hizalı incele.
