# SAK Early Warning Report

- **Event ID:** PCA-SAK-0003
- **Alarm time:** 2026-01-12T16:46:00+00:00
- **Event interval:** 2026-01-12T16:30:00+00:00 — 2026-01-12T18:34:00+00:00
- **Anomaly score:** 0.2281
- **Threshold:** 0.0627
- **Risk level:** HIGH
- **Operational context:** operational_mode=payload, eclipse=False, orbit_phase=0.4791666666666667
- **Critical time window:** 2026-01-12T16:40:00+00:00 — 2026-01-12T16:50:00+00:00
- **Possible subsystem:** COMM, AOCS
- **Attribution concentration:** 80.9%
- **Model confidence / uncertainty:** Henüz kalibre edilmedi

## Top Contributing Telemetry Channels

- receiver_rssi: 0.584 (COMM) [low]
- reaction_wheel_speed: 0.142 (AOCS) [high]
- panel_temperature: 0.083 (THERMAL) [high]
- battery_temperature: 0.064 (EPS) [high]
- bus_voltage: 0.042 (EPS) [low]

## Engineering Interpretation

COMM grubunda reconstruction error yükseldi. Başlıca kanallar: receiver_rssi, reaction_wheel_speed, panel_temperature. Bu çıktı kök neden kanıtı değil, mühendislik inceleme önceliğidir.

## Suggested Next Inspection

1. İlgili alt sistemin limit ve durum telemetrilerini doğrula.
2. Aynı operasyon modu ve yörünge fazındaki nominal örneklerle karşılaştır.
3. Komut, olay ve bakım kayıtlarını kritik pencereyle zaman hizalı incele.
