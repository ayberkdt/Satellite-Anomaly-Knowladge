# SAK Early Warning Report

- **Event ID:** PCA-SAK-0006
- **Alarm time:** 2026-01-13T08:07:00+00:00
- **Event interval:** 2026-01-13T08:05:00+00:00 — 2026-01-13T08:23:00+00:00
- **Anomaly score:** 0.0911
- **Threshold:** 0.0627
- **Risk level:** LOW
- **Operational context:** operational_mode=nominal, eclipse=False, orbit_phase=0.07291666666666667
- **Critical time window:** 2026-01-13T08:05:00+00:00 — 2026-01-13T08:12:00+00:00
- **Possible subsystem:** EPS, COMM
- **Attribution concentration:** 69.2%
- **Model confidence / uncertainty:** Henüz kalibre edilmedi

## Top Contributing Telemetry Channels

- bus_voltage: 0.303 (EPS) [high]
- payload_temperature: 0.213 (THERMAL) [high]
- receiver_rssi: 0.176 (COMM) [high]
- transmitter_power: 0.116 (COMM) [low]
- reaction_wheel_speed: 0.058 (AOCS) [high]

## Engineering Interpretation

EPS grubunda reconstruction error yükseldi. Başlıca kanallar: bus_voltage, payload_temperature, receiver_rssi. Bu çıktı kök neden kanıtı değil, mühendislik inceleme önceliğidir.

## Suggested Next Inspection

1. İlgili alt sistemin limit ve durum telemetrilerini doğrula.
2. Aynı operasyon modu ve yörünge fazındaki nominal örneklerle karşılaştır.
3. Komut, olay ve bakım kayıtlarını kritik pencereyle zaman hizalı incele.
