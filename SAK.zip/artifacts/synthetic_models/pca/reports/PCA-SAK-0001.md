# SAK Early Warning Report

- **Event ID:** PCA-SAK-0001
- **Alarm time:** 2026-01-12T06:57:00+00:00
- **Event interval:** 2026-01-12T06:50:00+00:00 — 2026-01-12T07:28:00+00:00
- **Anomaly score:** 48.0284
- **Threshold:** 0.0627
- **Risk level:** HIGH
- **Operational context:** operational_mode=payload, eclipse=False, orbit_phase=0.34375
- **Critical time window:** 2026-01-12T06:52:00+00:00 — 2026-01-12T07:02:00+00:00
- **Possible subsystem:** EPS, AOCS
- **Attribution concentration:** 86.2%
- **Model confidence / uncertainty:** Henüz kalibre edilmedi

## Top Contributing Telemetry Channels

- bus_voltage: 0.779 (EPS) [high]
- battery_voltage: 0.042 (EPS) [high]
- reaction_wheel_speed: 0.041 (AOCS) [high]
- transmitter_power: 0.032 (COMM) [high]
- battery_current: 0.027 (EPS) [high]

## Engineering Interpretation

EPS grubunda reconstruction error yükseldi. Başlıca kanallar: bus_voltage, battery_voltage, reaction_wheel_speed. Bu çıktı kök neden kanıtı değil, mühendislik inceleme önceliğidir.

## Suggested Next Inspection

1. İlgili alt sistemin limit ve durum telemetrilerini doğrula.
2. Aynı operasyon modu ve yörünge fazındaki nominal örneklerle karşılaştır.
3. Komut, olay ve bakım kayıtlarını kritik pencereyle zaman hizalı incele.
