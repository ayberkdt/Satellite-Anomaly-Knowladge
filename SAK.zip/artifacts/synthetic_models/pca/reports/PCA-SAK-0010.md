# SAK Early Warning Report

- **Event ID:** PCA-SAK-0010
- **Alarm time:** 2026-01-14T04:06:00+00:00
- **Event interval:** 2026-01-14T04:05:00+00:00 — 2026-01-14T04:08:00+00:00
- **Anomaly score:** 0.0732
- **Threshold:** 0.0627
- **Risk level:** LOW
- **Operational context:** operational_mode=payload, eclipse=False, orbit_phase=0.5625
- **Critical time window:** 2026-01-14T04:05:00+00:00 — 2026-01-14T04:08:00+00:00
- **Possible subsystem:** COMM, EPS
- **Attribution concentration:** 63.7%
- **Model confidence / uncertainty:** Henüz kalibre edilmedi

## Top Contributing Telemetry Channels

- transmitter_power: 0.314 (COMM) [high]
- receiver_rssi: 0.166 (COMM) [low]
- bus_voltage: 0.157 (EPS) [low]
- payload_temperature: 0.149 (THERMAL) [high]
- battery_voltage: 0.076 (EPS) [high]

## Engineering Interpretation

COMM grubunda reconstruction error yükseldi. Başlıca kanallar: transmitter_power, receiver_rssi, bus_voltage. Bu çıktı kök neden kanıtı değil, mühendislik inceleme önceliğidir.

## Suggested Next Inspection

1. İlgili alt sistemin limit ve durum telemetrilerini doğrula.
2. Aynı operasyon modu ve yörünge fazındaki nominal örneklerle karşılaştır.
3. Komut, olay ve bakım kayıtlarını kritik pencereyle zaman hizalı incele.
