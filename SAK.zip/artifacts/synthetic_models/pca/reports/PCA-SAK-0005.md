# SAK Early Warning Report

- **Event ID:** PCA-SAK-0005
- **Alarm time:** 2026-01-13T04:27:00+00:00
- **Event interval:** 2026-01-13T04:06:00+00:00 — 2026-01-13T04:49:00+00:00
- **Anomaly score:** 0.1199
- **Threshold:** 0.0627
- **Risk level:** MEDIUM
- **Operational context:** operational_mode=payload, eclipse=True, orbit_phase=0.78125
- **Critical time window:** 2026-01-13T04:10:00+00:00 — 2026-01-13T04:20:00+00:00
- **Possible subsystem:** EPS, THERMAL
- **Attribution concentration:** 85.4%
- **Model confidence / uncertainty:** Henüz kalibre edilmedi

## Top Contributing Telemetry Channels

- solar_array_current: 0.593 (EPS) [high]
- battery_voltage: 0.176 (EPS) [low]
- payload_temperature: 0.085 (THERMAL) [high]
- bus_voltage: 0.042 (EPS) [low]
- transmitter_power: 0.041 (COMM) [high]

## Engineering Interpretation

EPS grubunda reconstruction error yükseldi. Başlıca kanallar: solar_array_current, battery_voltage, payload_temperature. Bu çıktı kök neden kanıtı değil, mühendislik inceleme önceliğidir.

## Suggested Next Inspection

1. İlgili alt sistemin limit ve durum telemetrilerini doğrula.
2. Aynı operasyon modu ve yörünge fazındaki nominal örneklerle karşılaştır.
3. Komut, olay ve bakım kayıtlarını kritik pencereyle zaman hizalı incele.
