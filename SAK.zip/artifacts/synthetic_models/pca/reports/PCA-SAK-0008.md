# SAK Early Warning Report

- **Event ID:** PCA-SAK-0008
- **Alarm time:** 2026-01-13T21:07:00+00:00
- **Event interval:** 2026-01-13T20:04:00+00:00 — 2026-01-13T21:12:00+00:00
- **Anomaly score:** 0.1471
- **Threshold:** 0.0627
- **Risk level:** MEDIUM
- **Operational context:** operational_mode=nominal, eclipse=False, orbit_phase=0.19791666666666666
- **Critical time window:** 2026-01-13T20:43:00+00:00 — 2026-01-13T20:53:00+00:00
- **Possible subsystem:** THERMAL, EPS
- **Attribution concentration:** 76.8%
- **Model confidence / uncertainty:** Henüz kalibre edilmedi

## Top Contributing Telemetry Channels

- payload_temperature: 0.605 (THERMAL) [high]
- bus_voltage: 0.094 (EPS) [high]
- battery_temperature: 0.070 (EPS) [low]
- transmitter_power: 0.060 (COMM) [low]
- receiver_rssi: 0.056 (COMM) [high]

## Engineering Interpretation

THERMAL grubunda reconstruction error yükseldi. Başlıca kanallar: payload_temperature, bus_voltage, battery_temperature. Bu çıktı kök neden kanıtı değil, mühendislik inceleme önceliğidir.

## Suggested Next Inspection

1. İlgili alt sistemin limit ve durum telemetrilerini doğrula.
2. Aynı operasyon modu ve yörünge fazındaki nominal örneklerle karşılaştır.
3. Komut, olay ve bakım kayıtlarını kritik pencereyle zaman hizalı incele.
