# SAK Early Warning Report

- **Event ID:** PCA-SAK-0009
- **Alarm time:** 2026-01-14T02:06:00+00:00
- **Event interval:** 2026-01-14T01:00:00+00:00 — 2026-01-14T02:52:00+00:00
- **Anomaly score:** 1.6775
- **Threshold:** 0.0627
- **Risk level:** HIGH
- **Operational context:** operational_mode=nominal, eclipse=False, orbit_phase=0.3125
- **Critical time window:** 2026-01-14T01:35:00+00:00 — 2026-01-14T01:45:00+00:00
- **Possible subsystem:** EPS
- **Attribution concentration:** 79.0%
- **Model confidence / uncertainty:** Henüz kalibre edilmedi

## Top Contributing Telemetry Channels

- battery_voltage: 0.594 (EPS) [low]
- solar_array_voltage: 0.098 (EPS) [low]
- solar_array_current: 0.098 (EPS) [low]
- bus_voltage: 0.075 (EPS) [high]
- battery_current: 0.066 (EPS) [high]

## Engineering Interpretation

EPS grubunda reconstruction error yükseldi. Başlıca kanallar: battery_voltage, solar_array_voltage, solar_array_current. Bu çıktı kök neden kanıtı değil, mühendislik inceleme önceliğidir.

## Suggested Next Inspection

1. İlgili alt sistemin limit ve durum telemetrilerini doğrula.
2. Aynı operasyon modu ve yörünge fazındaki nominal örneklerle karşılaştır.
3. Komut, olay ve bakım kayıtlarını kritik pencereyle zaman hizalı incele.
