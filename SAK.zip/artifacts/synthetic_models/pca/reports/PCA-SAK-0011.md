# SAK Early Warning Report

- **Event ID:** PCA-SAK-0011
- **Alarm time:** 2026-01-14T08:08:00+00:00
- **Event interval:** 2026-01-14T08:03:00+00:00 — 2026-01-14T08:36:00+00:00
- **Anomaly score:** 0.1370
- **Threshold:** 0.0627
- **Risk level:** MEDIUM
- **Operational context:** operational_mode=nominal, eclipse=False, orbit_phase=0.08333333333333333
- **Critical time window:** 2026-01-14T08:03:00+00:00 — 2026-01-14T08:10:00+00:00
- **Possible subsystem:** THERMAL, COMM
- **Attribution concentration:** 57.3%
- **Model confidence / uncertainty:** Henüz kalibre edilmedi

## Top Contributing Telemetry Channels

- payload_temperature: 0.222 (THERMAL) [high]
- receiver_rssi: 0.177 (COMM) [high]
- panel_temperature: 0.174 (THERMAL) [high]
- bus_voltage: 0.149 (EPS) [high]
- transmitter_power: 0.146 (COMM) [low]

## Engineering Interpretation

THERMAL grubunda reconstruction error yükseldi. Başlıca kanallar: payload_temperature, receiver_rssi, panel_temperature. Bu çıktı kök neden kanıtı değil, mühendislik inceleme önceliğidir.

## Suggested Next Inspection

1. İlgili alt sistemin limit ve durum telemetrilerini doğrula.
2. Aynı operasyon modu ve yörünge fazındaki nominal örneklerle karşılaştır.
3. Komut, olay ve bakım kayıtlarını kritik pencereyle zaman hizalı incele.
