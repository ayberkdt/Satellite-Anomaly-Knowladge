# SAK Early Warning Report

- **Event ID:** PCA-SAK-0004
- **Alarm time:** 2026-01-12T23:57:00+00:00
- **Event interval:** 2026-01-12T22:48:00+00:00 — 2026-01-13T00:03:00+00:00
- **Anomaly score:** 0.2129
- **Threshold:** 0.0627
- **Risk level:** HIGH
- **Operational context:** operational_mode=nominal, eclipse=True, orbit_phase=0.96875
- **Critical time window:** 2026-01-12T23:50:00+00:00 — 2026-01-13T00:00:00+00:00
- **Possible subsystem:** EPS
- **Attribution concentration:** 74.1%
- **Model confidence / uncertainty:** Henüz kalibre edilmedi

## Top Contributing Telemetry Channels

- battery_voltage: 0.559 (EPS) [low]
- battery_current: 0.102 (EPS) [high]
- solar_array_voltage: 0.080 (EPS) [low]
- bus_voltage: 0.079 (EPS) [high]
- solar_array_current: 0.078 (EPS) [low]

## Engineering Interpretation

EPS grubunda reconstruction error yükseldi. Başlıca kanallar: battery_voltage, battery_current, solar_array_voltage. Bu çıktı kök neden kanıtı değil, mühendislik inceleme önceliğidir.

## Suggested Next Inspection

1. İlgili alt sistemin limit ve durum telemetrilerini doğrula.
2. Aynı operasyon modu ve yörünge fazındaki nominal örneklerle karşılaştır.
3. Komut, olay ve bakım kayıtlarını kritik pencereyle zaman hizalı incele.
