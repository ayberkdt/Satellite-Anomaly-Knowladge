# SAK Synthetic Results Summary

## Dataset

- Rows: 20160
- Channels: 13
- Train rows: 12096
- Validation rows: 4032
- Test rows: 4032
- Test events: 10

## Model Comparison

| model | event_precision | event_recall | event_f1 | false_alarms_per_day | median_delay_min | point_f1 | channel_hit_at_3 | subsystem_hit_at_2 | critical_window_hit_rate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| pca_global | 0.909 | 1.000 | 0.952 | 0.357 | 13.500 | 0.655 | 0.900 | 0.900 | 0.900 |
| pca_mode_aware | 0.833 | 1.000 | 0.909 | 0.714 | 13.000 | 0.655 | 0.900 | 0.900 | 0.900 |
| dense_autoencoder_global | 0.909 | 1.000 | 0.952 | 0.357 | 13.500 | 0.714 | 1.000 | 1.000 | 1.000 |
| dense_autoencoder_mode_aware | 0.769 | 1.000 | 0.870 | 1.071 | 13.500 | 0.714 | 1.000 | 1.000 | 1.000 |

## Threshold Sweep

| model | quantile | threshold | event_precision | event_recall | event_f1 | false_alarms_per_day | median_delay_min |
| --- | --- | --- | --- | --- | --- | --- | --- |
| pca_global | 0.990 | 0.059 | 0.833 | 1.000 | 0.909 | 0.714 | 13.000 |
| pca_global | 0.995 | 0.063 | 0.909 | 1.000 | 0.952 | 0.357 | 13.500 |
| pca_global | 0.999 | 0.067 | 1.000 | 1.000 | 1.000 | 0.000 | 13.500 |
| pca_mode_aware | 0.990 | 0.059 | 0.833 | 1.000 | 0.909 | 0.714 | 13.000 |
| pca_mode_aware | 0.995 | 0.063 | 0.833 | 1.000 | 0.909 | 0.714 | 13.000 |
| pca_mode_aware | 0.999 | 0.067 | 1.000 | 1.000 | 1.000 | 0.000 | 13.500 |
| dense_autoencoder_global | 0.990 | 0.053 | 0.769 | 1.000 | 0.870 | 1.071 | 13.500 |
| dense_autoencoder_global | 0.995 | 0.057 | 0.909 | 1.000 | 0.952 | 0.357 | 13.500 |
| dense_autoencoder_global | 0.999 | 0.065 | 0.909 | 1.000 | 0.952 | 0.357 | 14.000 |
| dense_autoencoder_mode_aware | 0.990 | 0.053 | 0.714 | 1.000 | 0.833 | 1.429 | 13.500 |
| dense_autoencoder_mode_aware | 0.995 | 0.057 | 0.769 | 1.000 | 0.870 | 1.071 | 13.500 |
| dense_autoencoder_mode_aware | 0.999 | 0.065 | 0.833 | 1.000 | 0.909 | 0.714 | 14.000 |

## Detection Delays

| model | true_event_id | predicted_event_id | detection_delay_min |
| --- | --- | --- | --- |
| pca_global | SYN-0001 | SAK-0001 | 2.000 |
| pca_global | SYN-0002 | SAK-0002 | 51.000 |
| pca_global | SYN-0003 | SAK-0003 | 2.000 |
| pca_global | SYN-0004 | SAK-0004 | 80.000 |
| pca_global | SYN-0005 | SAK-0005 | 48.000 |
| pca_global | SYN-0006 | SAK-0006 | -13.000 |
| pca_global | SYN-0007 | SAK-0007 | 2.000 |
| pca_global | SYN-0008 | SAK-0008 | 56.000 |
| pca_global | SYN-0009 | SAK-0009 | 2.000 |
| pca_global | SYN-0010 | SAK-0011 | 25.000 |
| pca_mode_aware | SYN-0001 | SAK-0001 | 2.000 |
| pca_mode_aware | SYN-0002 | SAK-0003 | 51.000 |
| pca_mode_aware | SYN-0003 | SAK-0004 | 2.000 |
| pca_mode_aware | SYN-0004 | SAK-0005 | 80.000 |
| pca_mode_aware | SYN-0005 | SAK-0006 | 48.000 |
| pca_mode_aware | SYN-0006 | SAK-0007 | -13.000 |
| pca_mode_aware | SYN-0007 | SAK-0008 | 2.000 |
| pca_mode_aware | SYN-0008 | SAK-0009 | 56.000 |
| pca_mode_aware | SYN-0009 | SAK-0010 | 2.000 |
| pca_mode_aware | SYN-0010 | SAK-0012 | 24.000 |
| dense_autoencoder_global | SYN-0001 | SAK-0001 | 2.000 |
| dense_autoencoder_global | SYN-0002 | SAK-0002 | 53.000 |
| dense_autoencoder_global | SYN-0003 | SAK-0003 | 2.000 |
| dense_autoencoder_global | SYN-0004 | SAK-0004 | 98.000 |
| dense_autoencoder_global | SYN-0005 | SAK-0005 | 46.000 |
| dense_autoencoder_global | SYN-0006 | SAK-0006 | -13.000 |
| dense_autoencoder_global | SYN-0007 | SAK-0007 | 2.000 |
| dense_autoencoder_global | SYN-0008 | SAK-0008 | 56.000 |
| dense_autoencoder_global | SYN-0009 | SAK-0009 | 2.000 |
| dense_autoencoder_global | SYN-0010 | SAK-0011 | 25.000 |
| dense_autoencoder_mode_aware | SYN-0001 | SAK-0001 | 2.000 |
| dense_autoencoder_mode_aware | SYN-0002 | SAK-0003 | 51.000 |
| dense_autoencoder_mode_aware | SYN-0003 | SAK-0004 | 2.000 |
| dense_autoencoder_mode_aware | SYN-0004 | SAK-0005 | 97.000 |
| dense_autoencoder_mode_aware | SYN-0005 | SAK-0006 | 48.000 |
| dense_autoencoder_mode_aware | SYN-0006 | SAK-0007 | -13.000 |
| dense_autoencoder_mode_aware | SYN-0007 | SAK-0008 | 2.000 |
| dense_autoencoder_mode_aware | SYN-0008 | SAK-0009 | 56.000 |
| dense_autoencoder_mode_aware | SYN-0009 | SAK-0010 | 2.000 |
| dense_autoencoder_mode_aware | SYN-0010 | SAK-0012 | 25.000 |
